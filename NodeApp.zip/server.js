const express = require('express');
const path = require('path');

const app = express();

// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(8080, () => {
    console.log('Server running on port 8080');
});